import React from 'react';
import MainPage from './components/MainPage';

function App() {
  return <MainPage />;
}

export default App;
