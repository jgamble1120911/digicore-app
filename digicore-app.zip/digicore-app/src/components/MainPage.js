import React from 'react';
import DigiAI from './DigiAI';

function MainPage() {
  return (
    <div className="main-container">
      <img src="/assets/digigate.gif" alt="Digigate Background" className="background-img" />
      <DigiAI />
    </div>
  );
}

export default MainPage;
