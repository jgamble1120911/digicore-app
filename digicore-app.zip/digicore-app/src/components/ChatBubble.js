import React from 'react';

function ChatBubble({ sender, text }) {
  return (
    <div className={`bubble ${sender}`}>
      <p>{text}</p>
    </div>
  );
}

export default ChatBubble;
