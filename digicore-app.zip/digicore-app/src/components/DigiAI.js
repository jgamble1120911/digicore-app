import React, { useState } from 'react';
import ChatBubble from './ChatBubble';

function DigiAI() {
  const [messages, setMessages] = useState([
    { sender: 'ai', text: "Hey Jayden, I'm DemiVeemon! I’ve got your back 💙" },
  ]);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg = { sender: 'user', text: input };
    const aiReply = { sender: 'ai', text: generateReply(input) };
    setMessages([...messages, userMsg, aiReply]);
    setInput('');
  };

  const generateReply = (text) => {
    const msg = text.toLowerCase();
    if (msg.includes("sad")) return "Sadness is okay... let's talk it through 🤍";
    if (msg.includes("hi") || msg.includes("hello")) return "Hii Jayden! I'm here with a hug 🫂";
    if (msg.includes("love")) return "You're deeply loved. I'm always on your side 💫";
    if (msg.includes("anxious")) return "Deep breath together... You're safe here 🫶";
    return "I'm here for whatever’s on your mind 💙";
  };

  return (
    <div className="chat-container">
      <img src="/assets/DemiVeemon.gif" alt="DemiVeemon" className="character-img" />
      <div className="chat-box">
        {messages.map((msg, idx) => (
          <ChatBubble key={idx} sender={msg.sender} text={msg.text} />
        ))}
        <div className="input-area">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Talk to DemiVeemon..."
          />
          <button onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
}

export default DigiAI;
